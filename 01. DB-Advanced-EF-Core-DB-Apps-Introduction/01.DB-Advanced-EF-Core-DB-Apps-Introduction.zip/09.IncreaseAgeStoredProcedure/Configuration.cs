﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _09.IncreaseAgeStoredProcedure
{
    public static class Configuration
    {
        public const string ConnectionString = "Server=(LocalDB)\\MSSQLLocalDB;Database = MinionsDB; Integrated Security=true;";
    }
}
