﻿namespace VaporStore.Data
{
	public static class Configuration
	{
		public static string ConnectionString =
            @"Server=(LocalDB)\MSSQLLocalDB;Database=VaporStore;Trusted_Connection=True";
	}
}